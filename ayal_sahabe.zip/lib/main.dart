import 'package:flutter/material.dart';

import 'package:ayal_sahabe/Model/model.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Center(child: const Text("Your Video Channel")),
        ),
        body: Center(
          child: FutureBuilder<List<Post>>(
            future: fetchPosts(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: Column(
                        children: [
                          GestureDetector(
                            onTap: () {},
                            child: Container(
                                height: 350,
                                width: 450,
                                color: Colors.amber,
                                child: Image.network('s')),
                          ),
                          Container(
                            width: 420,
                            child: Text(
                              snapshot.data![index].videoTitle as String,
                              style: TextStyle(
                                  fontSize: 16.0, fontFamily: 'ukij ekran'),
                              textDirection: TextDirection.rtl,
                            ),
                          ),
                          Container(
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 80.0,
                                ),
                                Container(
                                  color: Colors.brown,
                                  width: 130,
                                  child: Text(
                                    snapshot.data![index].categoryName
                                        as String,
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        fontFamily: 'ukij ekran'),
                                    textDirection: TextDirection.rtl,
                                  ),
                                ),
                                SizedBox(
                                  width: 5.0,
                                ),
                                Container(
                                  child: Icon(Icons.remove_red_eye_sharp),
                                ),
                                Container(
                                  child: Text(snapshot.data![index].totalviews
                                      as String),
                                ),
                                SizedBox(
                                  width: 5.0,
                                ),
                                Container(
                                  width: 115,
                                  child: Text(
                                    snapshot.data![index].categoryName
                                        as String,
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        fontFamily: 'ukij ekran'),
                                  ),
                                ),
                                Container(
                                  child: Icon(Icons.home),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    );
                  },
                );
              } else if (snapshot.hasError) {
                return Text("${snapshot.error}");
              }
              return const CircularProgressIndicator();
            },
          ),
        ),
      ),
    );
  }
}
