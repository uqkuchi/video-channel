import 'package:youtube_explode_dart/youtube_explode_dart.dart';

Future<String> getVideoThumbnail() async {
  var yt = YoutubeExplode();
  var videoId = 'xQRtBpVpD1E';
  var video = await yt.videos.get(videoId);
  yt.close();
  return 'https://img.youtube.com/vi/$videoId/${video.thumbnails.highResUrl}';
}
