package com.example.ayal_sahabe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
